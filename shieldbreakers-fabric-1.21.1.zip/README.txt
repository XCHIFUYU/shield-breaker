SHIELD BREAKER (Fabric 1.21.1)

Shield breaker toggle: press R (rebind in Controls) or type /shieldbreaker in chat.
Criticals toggle: press G or type /criticals in chat.

BUILD WITHOUT A PC:
1. Make a free GitHub repo, upload all these files (keep the folders).
2. Open the Actions tab > "build" > Run workflow.
3. Download the "shieldbreaker" artifact, unzip, get the .jar.
4. Put the .jar + Fabric API in your Pojav mods folder.

BUILD ON PC:  gradle build   (Java 21)  -> build/libs/

Criticals also work while sprinting: sprint is paused for the hit, then resumes.
