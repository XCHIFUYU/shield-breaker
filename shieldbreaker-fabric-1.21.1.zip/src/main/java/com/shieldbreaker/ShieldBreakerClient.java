package com.shieldbreaker;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.util.Set;

public class ShieldBreakerClient implements ClientModInitializer {
    private static final double RANGE = 5.0;

    // If you are holding one of these in your main hand, the mod will NOT auto-swap
    private static final Set<Item> UTILITY_ITEMS = Set.of(
            Items.ENDER_PEARL,
            Items.GOLDEN_APPLE,
            Items.ENCHANTED_GOLDEN_APPLE,
            Items.TOTEM_OF_UNDYING);

    private boolean enabled = false;
    private KeyBinding toggleKey;

    private boolean swapped = false;   // currently holding axe because of this mod
    private boolean hitDone = false;   // you hit the target while holding the axe
    private int prevSlot = -1;         // slot to go back to
    private int lockout = 0;           // ticks to wait before swapping again
    private PlayerEntity target;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.shieldbreaker.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.shieldbreaker"));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        // Chat command for phones with no keyboard: /shieldbreaker
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("shieldbreaker").executes(ctx -> {
                    toggle(MinecraftClient.getInstance());
                    return 1;
                })));

        // Detect your hit on the target while the axe is out
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && swapped && entity == target) {
                hitDone = true;
            }
            return ActionResult.PASS;
        });
    }

    private void toggle(MinecraftClient c) {
        enabled = !enabled;
        if (c.player != null) {
            if (!enabled) restore(c.player);
            c.player.sendMessage(Text.literal("Shield Breaker: " + (enabled ? "ON" : "OFF")), true);
        }
    }

    private void tick(MinecraftClient c) {
        while (toggleKey.wasPressed()) toggle(c);

        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) {
            swapped = false; hitDone = false; prevSlot = -1; target = null;
            return;
        }
        if (!enabled || c.currentScreen != null) return;

        if (lockout > 0) lockout--;

        target = findTarget(c, p);
        if (target == null) {
            restore(p);
            return;
        }

        if (swapped) {
            // go back after the hit, or if they dropped the shield
            if (hitDone || !target.isBlocking()) {
                restore(p);
                lockout = 4;
            }
            return;
        }

        // Only swap when the shield is up (a shield on cooldown can't be raised)
        if (lockout == 0 && target.isBlocking()) {
            swapToAxe(p);
        }
    }

    private PlayerEntity findTarget(MinecraftClient c, ClientPlayerEntity p) {
        PlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (PlayerEntity other : c.world.getPlayers()) {
            if (other == p || !other.isAlive() || other.isSpectator()) continue;
            double d = p.distanceTo(other);
            if (d <= RANGE && d < bestDist && p.canSee(other)) {
                best = other;
                bestDist = d;
            }
        }
        return best;
    }

    private void swapToAxe(ClientPlayerEntity p) {
        int current = p.getInventory().selectedSlot;
        ItemStack held = p.getInventory().getStack(current);

        if (UTILITY_ITEMS.contains(held.getItem())) return; // holding pearl/gapple/totem: don't swap
        if (held.isIn(ItemTags.AXES)) return;               // already holding an axe

        int bestSlot = -1;
        int bestScore = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isIn(ItemTags.AXES)) continue;
            int score = axeScore(s);
            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }

        if (bestSlot >= 0) {
            prevSlot = current;
            p.getInventory().selectedSlot = bestSlot;
            swapped = true;
            hitDone = false;
        }
    }

    // Higher tier first, then more enchantments (Sharpness, Efficiency, etc.)
    private static int axeScore(ItemStack s) {
        Item i = s.getItem();
        int tier;
        if (i == Items.NETHERITE_AXE) tier = 6;
        else if (i == Items.DIAMOND_AXE) tier = 5;
        else if (i == Items.IRON_AXE) tier = 4;
        else if (i == Items.STONE_AXE) tier = 3;
        else if (i == Items.GOLDEN_AXE) tier = 2;
        else if (i == Items.WOODEN_AXE) tier = 1;
        else tier = 3; // modded axes
        return tier * 1000 + s.getEnchantments().getSize();
    }

    private void restore(ClientPlayerEntity p) {
        if (swapped && prevSlot >= 0) {
            p.getInventory().selectedSlot = prevSlot;
        }
        swapped = false;
        hitDone = false;
        prevSlot = -1;
    }
}
